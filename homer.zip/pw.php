<?php
// Memeriksa apakah ada data yang dikirim melalui metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Mengambil nilai yang dikirimkan melalui form
  $username = $_POST["username"];
  $password = $_POST["password"];

  // Melakukan validasi login
  if ($username === "wibu" && $password === "jawir") {
    // Jika login berhasil, redirect ke halaman utama
    header("Location: data.html");
    exit();
  } else {
    // Jika login gagal, tampilkan pesan error
    $error = "Username atau password salah!";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Proses Login</title>
</head>
<body>
  <?php if (isset($error)) { ?>
    <p><?php echo $error; ?></p>
  <?php } ?>
</body>
</html>